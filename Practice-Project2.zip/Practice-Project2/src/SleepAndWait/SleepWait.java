package SleepAndWait;

public class SleepWait {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final Object lock = new Object(); // Object used for synchronization

        // Sleep Demo
        System.out.println("Sleep Demo:");

        Runnable sleepTask = () -> {
            try {
                Thread.sleep(2000); // Sleep for 2 seconds
                System.out.println("Sleep task completed");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        };

        Thread sleepThread = new Thread(sleepTask);
        sleepThread.start();

        System.out.println("Main thread continues while sleep thread is running");

        try {
            sleepThread.join(); // Wait for sleepThread to finish execution
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Main thread resumes after sleep thread completes");

        // Wait Demo
        System.out.println("\nWait Demo:");

        Runnable waitTask = () -> {
            synchronized (lock) {
                try {
                    System.out.println("Wait task is waiting");
                    lock.wait(); // Wait until notified
                    System.out.println("Wait task resumes execution");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };

        Thread waitThread = new Thread(waitTask);
        waitThread.start();

        try {
            Thread.sleep(2000); // Sleep for 2 seconds before notifying
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        synchronized (lock) {
            lock.notify(); // Notify the waiting thread
        }
    }

	}



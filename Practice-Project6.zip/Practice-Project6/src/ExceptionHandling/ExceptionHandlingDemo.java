package ExceptionHandling;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionHandlingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter an integer: ");
            int num1 = scanner.nextInt();

            System.out.print("Enter another integer: ");
            int num2 = scanner.nextInt();

            int result = divide(num1, num2);
            System.out.println("Result: " + result);
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter integers only.");
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero is not allowed.");
        } finally {
            scanner.close();
        }
    }

    public static int divide(int num1, int num2) {
        return num1 / num2;
    }

	}



package ThrowFinallyJava;
class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

class Demo {
    public static void main(String[] args) {
        try {
            performTask();
        } catch (CustomException e) {
            System.out.println("Caught CustomException: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
    }

    public static void performTask() throws CustomException {
        try {
            doSomething();
            throw new CustomException("CustomException occurred!");
        } catch (Exception e) {
            System.out.println("Caught Exception: " + e.getMessage());
        }
    }

    public static void doSomething() throws CustomException {
        try {
            // Perform some task
            int result = 10 / 0; // This line throws an ArithmeticException
        } catch (ArithmeticException e) {
            throw new CustomException("Error occurred during task execution!");
        }
    }
}

package CRUDdemo;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Scanner;

public class CRUD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner = new Scanner(System.in);
	        String directoryPath = "C:/example/";  // Directory path where files will be stored

	        // Create the directory if it doesn't exist
	        File directory = new File(directoryPath);
	        if (!directory.exists()) {
	            directory.mkdirs();
	        }

	        while (true) {
	            System.out.println("File CRUD Operations");
	            System.out.println("1. Create file");
	            System.out.println("2. Read file");
	            System.out.println("3. Update file");
	            System.out.println("4. Delete file");
	            System.out.println("5. Exit");
	            System.out.print("Enter your choice: ");
	            int choice = scanner.nextInt();
	            scanner.nextLine();  // Consume the newline character

	            switch (choice) {
	                case 1:
	                    System.out.print("Enter the file name: ");
	                    String createFileName = scanner.nextLine();
	                    createFile(directoryPath, createFileName);
	                    break;
	                case 2:
	                    System.out.print("Enter the file name: ");
	                    String readFileName = scanner.nextLine();
	                    readFile(directoryPath, readFileName);
	                    break;
	                case 3:
	                    System.out.print("Enter the file name: ");
	                    String updateFileName = scanner.nextLine();
	                    System.out.print("Enter the new content: ");
	                    String content = scanner.nextLine();
	                    updateFile(directoryPath, updateFileName, content);
	                    break;
	                case 4:
	                    System.out.print("Enter the file name: ");
	                    String deleteFileName = scanner.nextLine();
	                    deleteFile(directoryPath, deleteFileName);
	                    break;
	                case 5:
	                    System.out.println("Exiting program...");
	                    System.exit(0);
	                    break;
	                default:
	                    System.out.println("Invalid choice!");
	            }
	        }
	    }

	    private static void createFile(String directoryPath, String fileName) {
	        try {
	            Path filePath = Path.of(directoryPath + fileName);
	            Files.createFile(filePath);
	            System.out.println("File created successfully.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while creating the file: " + e.getMessage());
	        }
	    }

	    private static void readFile(String directoryPath, String fileName) {
	        try {
	            Path filePath = Path.of(directoryPath + fileName);
	            String content = Files.readString(filePath);
	            System.out.println("File content:");
	            System.out.println(content);
	        } catch (IOException e) {
	            System.out.println("An error occurred while reading the file: " + e.getMessage());
	        }
	    }

	    private static void updateFile(String directoryPath, String fileName, String content) {
	        try {
	            Path filePath = Path.of(directoryPath + fileName);
	            Files.writeString(filePath, content);
	            System.out.println("File updated successfully.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while updating the file: " + e.getMessage());
	        }
	    }

	    private static void deleteFile(String directoryPath, String fileName) {
	        try {
	            Path filePath = Path.of(directoryPath + fileName);
	            Files.delete(filePath);
	            System.out.println("File deleted successfully.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while deleting the file: " + e.getMessage());
	        }
	    }
	
	}



package BasicJava;

	class Vehicle {
		    private String brand;
		    private int year;

		    public Vehicle(String brand, int year) {
		        this.brand = brand;
		        this.year = year;
		    }

		    public void startEngine() {
		        System.out.println("Engine started for " + brand);
		    }

		    public void stopEngine() {
		        System.out.println("Engine stopped for " + brand);
		    }

		    public void displayInfo() {
		        System.out.println("Brand: " + brand);
		        System.out.println("Year: " + year);
		    }
		}

		// Class representing a car, inheriting from Vehicle
		class Car extends Vehicle {
		    private int numDoors;

		    public Car(String brand, int year, int numDoors) {
		        super(brand, year);
		        this.numDoors = numDoors;
		    }

		    @Override
		    public void displayInfo() {
		        super.displayInfo();
		        System.out.println("Number of doors: " + numDoors);
		    }

		    public void drive() {
		        System.out.println("Driving the car");
		    }
		}

		// Class representing a motorcycle, inheriting from Vehicle
		class Motorcycle extends Vehicle {
		    private boolean hasSidecar;

		    public Motorcycle(String brand, int year, boolean hasSidecar) {
		        super(brand, year);
		        this.hasSidecar = hasSidecar;
		    }

		    @Override
		    public void displayInfo() {
		        super.displayInfo();
		        System.out.println("Has sidecar: " + hasSidecar);
		    }

		    public void ride() {
		        System.out.println("Riding the motorcycle");
		    }
		}

		// Main class
		public class OOPDemo {
		    public static void main(String[] args) {
		        // Create objects and demonstrate OOP concepts
		        Vehicle vehicle = new Vehicle("Generic Vehicle", 2020);
		        vehicle.startEngine();
		        vehicle.displayInfo();
		        vehicle.stopEngine();
		        System.out.println();

		        Car car = new Car("Toyota", 2019, 4);
		        car.startEngine();
		        car.displayInfo();
		        car.drive();
		        car.stopEngine();
		        System.out.println();

		        Motorcycle motorcycle = new Motorcycle("Harley-Davidson", 2022, false);
		        motorcycle.startEngine();
		        motorcycle.displayInfo();
		        motorcycle.ride();
		        motorcycle.stopEngine();
		    }
		}
	


package ThreadJava;
//Thread class
class MyThread extends Thread {
 @Override
 public void run() {
     System.out.println("Thread is running by extending Thread class.");
 }
}

//Runnable class
class MyRunnable implements Runnable {
 @Override
 public void run() {
     System.out.println("Thread is running by implementing Runnable interface.");
 }
}

public class Main {
 public static void main(String[] args) {
     // Creating and starting a thread by extending Thread class
     MyThread thread1 = new MyThread();
     thread1.start();

     // Creating and starting a thread by implementing Runnable interface
     MyRunnable runnable = new MyRunnable();
     Thread thread2 = new Thread(runnable);
     thread2.start();
 }
}




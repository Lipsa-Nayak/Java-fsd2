package MultipleInheritance;


		interface Animal {
		    default void sound() {
		        System.out.println("Animal makes a sound");
		    }
		}

		interface Cat extends Animal {
		    default void sound() {
		        System.out.println("Cat meows");
		    }
		}

		interface Dog extends Animal {
		    default void sound() {
		        System.out.println("Dog barks");
		    }
		}

		class AnimalSound implements Cat, Dog {
		    public void sound() {
		        Cat.super.sound(); // Resolve conflict by explicitly invoking Cat's default method
		        Dog.super.sound(); // Resolve conflict by explicitly invoking Dog's default method
		    }
		}

		public class MultipleInheritanceEx {
		    public static void main(String[] args) {
		        AnimalSound animalSound = new AnimalSound();
		        animalSound.sound();
		    }
		
	}


